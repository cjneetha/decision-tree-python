Programming Language : Python 3.6.3

How to run : 
Req:
	Python version : 3.6.3 
	Please keep the car.data file on the same folder as the main.py

Terminal/Command Line:  
	python3 main.py

Result:
The resulting tree is represented via an xml
Output file : 
	output_final.xml
This output file will be generated in the same folder as the program.
